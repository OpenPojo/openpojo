package com.openpojotest;

public class AClass {
  public String sayHello() {
    return "Hello World!";
  }
}
