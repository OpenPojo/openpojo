package com.openpojotest;

public class AndAnotherClass {
  public String getGreetingMessage(final String name) {
    return "Hello " + name + ", so good to meet you";
  }
}
